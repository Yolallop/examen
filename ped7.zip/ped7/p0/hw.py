# Hello World in Python
print "Hola Mundo!"
