int main(int argc, char* argv[])
{
    int a = 3;
    char b[] = "hola";
    int c = 7;

    int d = a+c;
    int e = a+b;
    return 0;
}
