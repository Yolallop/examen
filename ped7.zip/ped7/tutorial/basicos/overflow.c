#include <stdio.h>

int main()
{
    unsigned char a = 250;
    unsigned char b = 10;
    unsigned char c = a + b;

    printf("a=%hu b=%hu c=%hu\n");
}
