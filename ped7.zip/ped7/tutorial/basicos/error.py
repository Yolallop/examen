a = 3
b = "hola"
c = 7

d = a + c
e = a + b
