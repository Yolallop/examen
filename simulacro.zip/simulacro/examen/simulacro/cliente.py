import socket, sys
from fecha_hora import Fecha_Hora

# creo socket
sc = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, 0) 

dir_socket = input("Introduzca la dirección del servidor") 
puerto = input("Introduzca el puerto del servidor ")
if not dir_socket:
    dir_socket = 'localhost'
if not puerto:
    puerto = '5555'

mensaje = Fecha_Hora()
peticion = mensaje.pide()
sc.sendto(peticion.encode('utf8'), (dir_socket, int(puerto)))

data, dir = sc.recvfrom(1024)
sys.stdout.write(data.decode('utf8').strip()) 
print("\n")
sc.close()