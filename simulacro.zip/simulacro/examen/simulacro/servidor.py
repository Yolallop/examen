import socket
import os
import datetime

from fecha_hora import Fecha_Hora

ss = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # Crear socket

dir_socket = input("Introduzca la dirección del servidor: ")
puerto = input("Introduzca el puerto del servidor: ")
if not dir_socket:
    dir_socket = 'localhost'
if not puerto:
    puerto = '5555'
try:
    ss.bind((dir_socket, int(puerto)))
    print("Servidor escuchando en", dir_socket, puerto)
except Exception as e:
    print("Error al asignar una dirección al servidor", e)
    exit()
mensaje = Fecha_Hora()

while True:
    data, dirc = ss.recvfrom(1024)
    peticion = data.decode('utf8')
    pid = os.fork()
    if pid:
        continue
    else:
        if mensaje.comprobar_hora(peticion):
            print("El cliente", dirc, "pide  hora")
            tiempo = mensaje.hora()
            ss.sendto(str(tiempo).encode('utf8'), dirc)
        elif mensaje.comprobar_fecha(peticion):
            print("El cliente", dirc, "pide fecha")
            tiempo = mensaje.fecha()
            ss.sendto(str(tiempo).encode('utf8'), dirc)
        else:
            print("El cliente", dirc, "equivocado")
            ss.sendto("Error".encode('utf8'), dirc)
        exit()
